# NIHANTH COMPANY HCM - Deployment Guide

To fix the "Could not resolve entry module 'index.html'" error, your GitHub repository **must** follow this exact folder structure. Vite will not find your files if they are in the wrong place.

## Required Folder Structure
```text
/ (Your Repository Root)
├── index.html              <-- MUST BE HERE (Not in src!)
├── package.json            <-- MUST BE HERE
├── vercel.json             <-- MUST BE HERE
├── README.md
└── src/                    <-- Folder for logic
    ├── main.jsx            <-- Entry point script
    ├── App.jsx             <-- Main UI Shell
    └── routes.js           <-- Navigation logic
```

## Checklist for Success:
1. **Move index.html:** If your `index.html` is inside a folder named `public` or `src`, move it out to the main directory.
2. **Check package.json:** Ensure the `build` script says exactly `"vite build"`.
3. **Check index.html path:** Ensure the script tag looks like this: `<script type="module" src="/src/main.jsx"></script>`. Note the leading slash.

Copy the code from the other documents on the canvas to ensure your file contents are correct.