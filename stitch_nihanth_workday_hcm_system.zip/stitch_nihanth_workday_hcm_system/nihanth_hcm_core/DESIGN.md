---
name: NIHANTH HCM Core
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#43474f'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737780'
  outline-variant: '#c3c6d1'
  surface-tint: '#3a5f94'
  primary: '#001e40'
  on-primary: '#ffffff'
  primary-container: '#003366'
  on-primary-container: '#799dd6'
  inverse-primary: '#a7c8ff'
  secondary: '#515f74'
  on-secondary: '#ffffff'
  secondary-container: '#d5e3fc'
  on-secondary-container: '#57657a'
  tertiary: '#002133'
  on-tertiary: '#ffffff'
  tertiary-container: '#003751'
  on-tertiary-container: '#0fa5e9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#a7c8ff'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#1f477b'
  secondary-fixed: '#d5e3fc'
  secondary-fixed-dim: '#b9c7df'
  on-secondary-fixed: '#0d1c2e'
  on-secondary-fixed-variant: '#3a485b'
  tertiary-fixed: '#c9e6ff'
  tertiary-fixed-dim: '#89ceff'
  on-tertiary-fixed: '#001e2f'
  on-tertiary-fixed-variant: '#004c6e'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  h1:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  table-header:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 20px
  sidebar-width: 260px
---

## Brand & Style

The design system is engineered for high-density enterprise environments where clarity, speed of data processing, and institutional trust are paramount. The brand personality is authoritative yet unobtrusive, functioning as a silent partner to the HR professional. 

The aesthetic follows a **Corporate / Modern** style, characterized by structured layouts, intentional whitespace, and a high-contrast information hierarchy. It avoids decorative flourishes in favor of functional precision, ensuring that the user’s cognitive load is reserved for complex decision-making rather than navigating the interface. The emotional response is one of reliability and "calm efficiency."

## Colors

The color palette is anchored in deep blues and slate grays to establish a sense of stability and professional rigor.

*   **Primary:** A deep Navy (#003366) used for navigation, primary actions, and brand identification.
*   **Secondary:** A Slate Gray (#475569) used for sub-navigation, supporting icons, and secondary text to provide visual balance.
*   **Tertiary:** A bright Sky Blue (#0EA5E9) reserved for interaction states, active focus indicators, and progress bars.
*   **Neutral:** A spectrum of crisp whites and cool grays (starting at #F8FAFC) to define surface layers and data table backgrounds.
*   **Semantic:** Standardized Success (Green), Warning (Amber), and Error (Red) tones are desaturated slightly to maintain the sophisticated enterprise aesthetic.

## Typography

The design system utilizes **Inter** exclusively to leverage its exceptional legibility in data-heavy contexts. The typographic scale is optimized for information density, prioritizing a clear vertical rhythm.

Headlines use a tighter letter-spacing and heavier weights to provide immediate structure to pages. Body text is set at 14px for the majority of UI interactions to balance readability with the need to display large volumes of employee data. Labels and table headers utilize uppercase styling with increased letter-spacing to distinguish metadata from content.

## Layout & Spacing

This design system employs a **Fluid Grid** for the main content area, anchored by a fixed-width sidebar for primary navigation. 

*   **Sidebar:** Fixed at 260px to ensure persistent access to organizational modules.
*   **Grid:** A 12-column system with 20px gutters allows for flexible dashboard widget configurations (typically 3, 4, or 6 column spans).
*   **Spacing Rhythm:** A 4px baseline grid ensures alignment across all components. For complex data tables, "compact" (4px) and "comfortable" (8px) vertical cell padding options are provided to accommodate different user densities.

## Elevation & Depth

To maintain a clean, enterprise look, the design system utilizes **Tonal Layers** and **Low-contrast outlines** rather than heavy shadows.

*   **Level 0 (Background):** The base canvas uses the softest neutral gray (#F8FAFC).
*   **Level 1 (Cards/Widgets):** Primary surfaces are pure white (#FFFFFF) with a 1px border in a light gray (#E2E8F0).
*   **Level 2 (Popovers/Modals):** These elements use a very soft, diffused ambient shadow (0px 4px 20px rgba(0, 0, 0, 0.05)) to suggest a slight lift from the page without breaking the "flat" professional aesthetic.
*   **Interactive Depth:** Hover states on interactive rows or cards are indicated by a subtle background color shift to #F1F5F9 rather than an increase in shadow.

## Shapes

The design system uses a **Soft** shape language. A corner radius of 4px (0.25rem) is applied to standard inputs, buttons, and status badges. This creates a modern look that feels approachable but remains sufficiently "square" to look professional and space-efficient in high-density data tables. Large dashboard widgets may use a `rounded-lg` (8px) radius to distinguish them as major layout containers.

## Components

The component library is optimized for the speed of HR workflows:

*   **Data Tables:** The core of the design system. Tables feature "Sticky Headers," sortable columns with chevron indicators, and multi-select checkboxes. Row height is standardized at 48px for standard view and 40px for compact view.
*   **Status Badges:** Small, rounded-pill containers with low-saturation background tints and high-contrast text. Example: "Active" (Light Green BG / Dark Green Text).
*   **Dashboard Widgets:** Standardized white containers with a 1px border. They must include a header area with a title (H3) and an optional "Action" link or icon.
*   **Buttons:** 
    *   *Primary:* Solid Navy background with White text.
    *   *Secondary:* White background with Navy border and text.
    *   *Ghost:* No background or border, Navy text; used for tertiary actions.
*   **Input Fields:** Subtle 1px borders (#CBD5E1) that thicken and change to Sky Blue (#0EA5E9) on focus. Labels always sit above the input field for maximum scanability.
*   **Navigation Sidebar:** Dark-themed (Primary Navy) with a vertical list of icons and labels. The active state is indicated by a Sky Blue left-border accent and a subtle background highlight.