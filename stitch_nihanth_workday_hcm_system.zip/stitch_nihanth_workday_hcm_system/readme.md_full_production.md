# NIHANTH COMPANY HCM - Enterprise Portal

A professional, high-fidelity HCM solution inspired by Workday, built for scalability and ease of use.

## Technical Stack
- **Framework:** React 18+ (Vite-powered)
- **Styling:** Tailwind CSS for enterprise-grade layouts
- **Icons:** Lucide-React
- **Visualization:** Recharts for HCM analytics
- **Database/Backend:** MongoDB (Planned)
- **Deployment:** Optimized for Vercel

## Configuration & Setup

### 1. Environment Variables
Create a `.env` file in the root directory and add the following keys (see `.env.example` for reference):
```text
MONGODB_URI=your_mongodb_uri
JWT_SECRET=your_jwt_secret
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

### 2. Project Structure
To avoid build errors, ensure your folder structure looks like this:
```text
/ (Root)
├── index.html
├── package.json
├── vercel.json
├── .env
└── src/
    ├── main.jsx
    ├── App.jsx
    └── routes.js
```

## Getting Started
1. Install dependencies: `npm install`
2. Run development server: `npm run dev`
3. Build for production: `npm run build`