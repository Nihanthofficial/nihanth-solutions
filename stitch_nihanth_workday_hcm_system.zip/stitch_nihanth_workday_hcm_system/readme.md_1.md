# NIHANTH COMPANY HCM

This is a high-fidelity Workday-inspired HCM portal for NIHANTH COMPANY.

## Structure
- `index.html`: Main Dashboard
- `profile.html`: Employee Directory/Profile
- `payroll.html`: Payroll & Benefits
- `recruiting.html`: Talent Acquisition

## Tech Stack
- HTML5
- CSS3 (Tailwind-based styling)
- Modern UI Components