# Vercel Deployment Checklist for NIHANTH COMPANY

The build error `Could not resolve entry module "index.html"` confirms that Vite cannot find your main entry point. Please ensure your folder structure looks **exactly** like this:

```text
Nihanth-Enterprises/ (Root Folder)
├── index.html           <-- MUST BE HERE
├── package.json         <-- MUST BE HERE
├── vercel.json          <-- MUST BE HERE
├── vite.config.js       <-- (Optional, but recommended)
└── src/
    ├── main.jsx         <-- React Entry Point
    ├── App.jsx          <-- UI Shell
    └── routes.js        <-- Routing mapping
```

### 1. The Critical Root index.html
Ensure `index.html` is in the **root** folder, not inside `src/`.
```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>NIHANTH COMPANY | HCM Enterprise</title>
  </head>
  <body>
    <div id="root"></div>
    <!-- This path must point to where your main.jsx is -->
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
```

### 2. src/main.jsx
Make sure your React mounting code is correct:
```javascript
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css' // If you have global styles

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
```

### 3. package.json Build Script
Your build script in `package.json` should be:
`"build": "vite build"`

### How to fix:
1. Move `index.html` from `src/` to the root folder if it's currently inside `src/`.
2. Commit and push the move to GitHub.
3. Vercel will automatically trigger a new build.
