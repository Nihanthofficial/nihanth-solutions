# NIHANTH COMPANY HCM - MASTER PROJECT SOURCE (CONSOLIDATED)

This document contains all the "Final Verified" code for your project, organized by their correct file paths to ensure your Vercel deployment succeeds.

---

## 📂 ROOT DIRECTORY
*These files must be in the top-level folder of your repository.*

### 1. index.html
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <meta content="NIHANTH COMPANY HCM Platform - Enterprise-grade Human Capital Management." name="description"/>
    <meta content="#0f172a" name="theme-color"/>
    <title>NIHANTH COMPANY | HCM Solutions</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <!-- Google Fonts: Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; margin: 0; }
        #root:empty {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-color: #ffffff;
        }
        #root:empty::after {
            content: "Loading NIHANTH COMPANY...";
            font-weight: 600;
            color: #0f172a;
        }
    </style>
</head>
<body class="antialiased text-slate-900">
    <div id="root"></div>
    <script src="/src/main.jsx" type="module"></script>
</body>
</html>
```

### 2. package.json
```json
{
  "name": "nihanth-hcm-enterprise",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "lucide-react": "^0.263.1",
    "recharts": "^2.7.2",
    "clsx": "^2.0.0",
    "tailwind-merge": "^1.14.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.15",
    "@types/react-dom": "^18.2.7",
    "@vitejs/plugin-react": "^4.0.3",
    "autoprefixer": "^10.4.14",
    "postcss": "^8.4.27",
    "tailwindcss": "^3.3.3",
    "vite": "^4.4.5"
  }
}
```

### 3. vercel.json
```json
{
  "framework": "vite",
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
```

### 4. .env.example
```text
MONGODB_URI=your_mongodb_uri_here
JWT_SECRET=your_jwt_secret_here
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

---

## 📂 src/ FOLDER
*These files must be inside a folder named 'src'.*

### 1. src/main.jsx
```javascript
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

console.log("NIHANTH HCM: Mounting application...");

const rootElement = document.getElementById('root');

if (!rootElement) {
  console.error("CRITICAL ERROR: Could not find <div id='root'> in index.html.");
} else {
  try {
    const root = ReactDOM.createRoot(rootElement);
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
    console.log("NIHANTH HCM: Application mounted successfully.");
  } catch (error) {
    console.error("NIHANTH HCM: Render Error:", error);
    rootElement.innerHTML = `<div style="padding: 20px; color: red;"><h1>Application Error</h1><p>${error.message}</p></div>`;
  }
}
```

### 2. src/App.jsx
*(Refer to Document {{DATA:DOCUMENT:DOCUMENT_16}} for the full code of the enterprise shell)*

### 3. src/routes.js
```javascript
export const routes = {
  dashboard: '/',
  employees: '/employees',
  payroll: '/payroll',
  recruiting: '/recruiting',
  settings: '/settings'
};
```

---

## 🚀 DEPLOYMENT INSTRUCTIONS
1. **Match Folder Structure**: Ensure your GitHub repo looks exactly like the paths above.
2. **Push to GitHub**: Vercel will auto-detect the Vite framework.
3. **Set Environment Variables**: Copy keys from `.env.example` to Vercel Settings > Environment Variables.
