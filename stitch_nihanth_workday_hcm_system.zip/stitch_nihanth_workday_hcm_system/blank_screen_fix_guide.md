# Troubleshooting a Blank Screen (White Page)

If you see a blank page after deploying to Vercel, it usually means the browser tried to load the app but something crashed immediately.

## 1. Check the Browser Console
- Right-click anywhere on the blank page.
- Select **Inspect** or **Inspect Element**.
- Click the **Console** tab.
- Look for **red error messages**.
  - *Error: "Failed to load resource"* -> The path to `main.jsx` in your `index.html` is wrong.
  - *Error: "Element type is invalid"* -> There is a mistake in how `App.jsx` is exported or imported.

## 2. Verify the Script Tag
In your `index.html` (at the root), ensure this line matches your folder structure:
`<script type="module" src="/src/main.jsx"></script>`
- If your file is called `main.js` (not `.jsx`), change it to `.js`.
- If your `main.jsx` is NOT in a `src` folder, remove the `src/` part.

## 3. Verify the Root Div
Your `index.html` MUST have this exact line inside the `<body>`:
`<div id="root"></div>`

## 4. Dependencies
Ensure you have run `npm install` locally. On Vercel, this happens automatically, but if a dependency is missing from `package.json`, the app won't start.

I have provided **Verified** versions of `index.html` and `main.jsx` on the canvas. Please copy those into your project.