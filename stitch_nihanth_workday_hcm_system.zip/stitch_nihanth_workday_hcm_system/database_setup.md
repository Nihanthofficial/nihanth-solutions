# Backend & Database Setup Guide

To connect your NIHANTH COMPANY HCM portal to a real database and storage, follow these steps:

## 1. Environment Variables
Create a file named `.env` in your project root and paste the values from the `.env.example` file on the canvas. **Never commit the `.env` file to GitHub.**

## 2. MongoDB Setup
1. Create a cluster on [MongoDB Atlas](https://www.mongodb.com/cloud/atlas).
2. Get your connection string and paste it as `MONGODB_URI`.

## 3. Cloudinary Setup (For Employee Photos)
1. Sign up at [Cloudinary](https://cloudinary.com/).
2. Copy your Cloud Name, API Key, and API Secret to your `.env` file.

## 4. Vercel Configuration
In your Vercel Dashboard:
1. Go to **Settings > Environment Variables**.
2. Add each key-value pair from your `.env` file there so the production build can access them.

## 5. Backend Integration
You'll need a `/api` folder for your serverless functions (if using Vercel Functions). I can help you draft the basic API structure for employee data if you're ready.